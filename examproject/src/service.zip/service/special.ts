import request from '../utils/request';

// 登陆
export let special = () => {
    // console.log(params)
    return request.get('manger/grade');
}

